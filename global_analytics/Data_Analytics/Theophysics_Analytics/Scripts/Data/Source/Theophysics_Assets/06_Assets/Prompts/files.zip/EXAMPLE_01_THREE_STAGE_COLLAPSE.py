"""
THREE-STAGE WAVE FUNCTION COLLAPSE
Shows: Superposition → Observation → Actualization
Core concept: How consciousness selects one outcome from many
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Color constants
DARK_BG = '#0a0a0a'
CYAN_OBSERVER = '#00FFFF'
GOLD_LOGOS = '#FFD700'
PURPLE_FIELD = '#9933FF'
GREEN_ACTUAL = '#00FF00'
WHITE_SOURCE = '#FFFFFF'

# Setup figure
fig = plt.figure(figsize=(24, 16), facecolor=DARK_BG)
ax = fig.add_subplot(111, projection='3d', facecolor=DARK_BG)
ax.set_axis_off()

# ============================================
# STAGE 1: SUPERPOSITION (Left side)
# ============================================
# Multiple possible states existing simultaneously

# Create probability cloud
n_particles = 1000
x_super = np.random.randn(n_particles) * 2.5 - 8
y_super = np.random.randn(n_particles) * 2.5
z_super = np.random.randn(n_particles) * 2.5

ax.scatter(x_super, y_super, z_super,
           c=PURPLE_FIELD, alpha=0.2, s=40, marker='o')

# Add wireframe sphere showing extent
theta = np.linspace(0, 2*np.pi, 30)
phi = np.linspace(0, np.pi, 20)
THETA, PHI = np.meshgrid(theta, phi)

r_wire = 3
x_wire = r_wire * np.sin(PHI) * np.cos(THETA) - 8
y_wire = r_wire * np.sin(PHI) * np.sin(THETA)
z_wire = r_wire * np.cos(PHI)

ax.plot_wireframe(x_wire, y_wire, z_wire,
                  color=PURPLE_FIELD, alpha=0.3, linewidth=1)

# Label
ax.text(-8, 0, 4.5, 'STAGE 1', color=PURPLE_FIELD,
        fontsize=32, weight='bold', ha='center')
ax.text(-8, 0, 3.8, 'Superposition', color=PURPLE_FIELD,
        fontsize=20, ha='center', style='italic')

# ============================================
# STAGE 2: OBSERVATION (Center)
# ============================================
# Consciousness measuring/selecting

observer_z = 2
# Observer sphere (consciousness)
r_obs = 0.8
x_obs = r_obs * np.sin(PHI) * np.cos(THETA)
y_obs = r_obs * np.sin(PHI) * np.sin(THETA)
z_obs = r_obs * np.cos(PHI) + observer_z

ax.plot_surface(x_obs, y_obs, z_obs,
                color=CYAN_OBSERVER, alpha=0.7, linewidth=0)

# Add glow halos
for r_glow in [1.2, 1.6, 2.0]:
    x_halo = r_glow * np.sin(PHI) * np.cos(THETA)
    y_halo = r_glow * np.sin(PHI) * np.sin(THETA)
    z_halo = r_glow * np.cos(PHI) + observer_z
    
    alpha_val = 0.3 * (2.4 - r_glow)
    ax.plot_surface(x_halo, y_halo, z_halo,
                   color=CYAN_OBSERVER, alpha=alpha_val, linewidth=0)

# Observation rays emanating
for i in range(12):
    angle = i * 2*np.pi/12
    x_ray = np.linspace(0.5*np.cos(angle), -8 + 3*np.cos(angle), 50)
    y_ray = np.linspace(0.5*np.sin(angle), 3*np.sin(angle), 50)
    z_ray = np.linspace(observer_z, np.sin(angle*3)*2, 50)
    
    ax.plot(x_ray, y_ray, z_ray,
           color=CYAN_OBSERVER, linewidth=3, alpha=0.6)

# Collapsing probability cloud
for step in range(6):
    phi_val = step * 0.35
    collapse_factor = np.exp(-(phi_val**2))
    
    for angle in np.linspace(0, 2*np.pi, 40):
        r_collapse = 0.8 + phi_val * 2.5
        x_col = (r_collapse * 0.4)*np.cos(angle)
        y_col = (r_collapse * 0.4)*np.sin(angle)
        z_col = 0.5*np.sin(angle*2)
        
        ax.scatter([x_col], [y_col], [z_col],
                  c=PURPLE_FIELD, s=150*collapse_factor,
                  alpha=0.4*collapse_factor, marker='o')

# Label
ax.text(0, 0, 4.5, 'STAGE 2', color=CYAN_OBSERVER,
        fontsize=32, weight='bold', ha='center')
ax.text(0, 0, 3.8, 'Observation', color=CYAN_OBSERVER,
        fontsize=20, ha='center', style='italic')

# ============================================
# STAGE 3: ACTUALIZED STATE (Right side)
# ============================================
# Single definite outcome selected

# Central bright point
ax.scatter([8], [0], [0], c=WHITE_SOURCE, s=1500, alpha=1.0,
          edgecolors=GREEN_ACTUAL, linewidth=5)

# Definite state sphere
r_actual = 0.8
x_actual = r_actual * np.sin(PHI) * np.cos(THETA) + 8
y_actual = r_actual * np.sin(PHI) * np.sin(THETA)
z_actual = r_actual * np.cos(PHI)

ax.plot_surface(x_actual, y_actual, z_actual,
                color=GREEN_ACTUAL, alpha=0.8, linewidth=0)

# Add glow
for r_glow in [1.2, 1.6, 2.0]:
    x_glow = r_glow * np.sin(PHI) * np.cos(THETA) + 8
    y_glow = r_glow * np.sin(PHI) * np.sin(THETA)
    z_glow = r_glow * np.cos(PHI)
    
    alpha_val = 0.4 * (2.4 - r_glow)
    ax.plot_surface(x_glow, y_glow, z_glow,
                   color=GREEN_ACTUAL, alpha=alpha_val, linewidth=0)

# Label
ax.text(8, 0, 4.5, 'STAGE 3', color=GREEN_ACTUAL,
        fontsize=32, weight='bold', ha='center')
ax.text(8, 0, 3.8, 'Actualized', color=GREEN_ACTUAL,
        fontsize=20, ha='center', style='italic')

# ============================================
# CONNECTING ARROWS
# ============================================
# Stage 1 → 2
ax.plot([-5, -2], [0, 0], [2, 2],
       color=WHITE_SOURCE, linewidth=4, alpha=0.6)
ax.scatter([-2], [0], [2], c=WHITE_SOURCE, s=200, marker='>')

# Stage 2 → 3
ax.plot([2, 5], [0, 0], [2, 0],
       color=WHITE_SOURCE, linewidth=4, alpha=0.6)
ax.scatter([5], [0], [0], c=WHITE_SOURCE, s=200, marker='>')

# ============================================
# MAIN TITLE
# ============================================
fig.text(0.5, 0.98, 'THE THREE-STAGE WAVE FUNCTION COLLAPSE',
         ha='center', fontsize=72, color='white', weight='bold')

fig.text(0.5, 0.94, 'How consciousness selects definite reality from quantum potential',
         ha='center', fontsize=28, color=CYAN_OBSERVER, style='italic')

# ============================================
# BOTTOM TAGLINE
# ============================================
fig.text(0.5, 0.02, 'Ψ(many) → χ(observer) → ψ(one)',
         ha='center', fontsize=32, color=GOLD_LOGOS,
         weight='bold', style='italic')

# ============================================
# VIEW & SAVE
# ============================================
ax.view_init(elev=20, azim=45)
ax.set_xlim([-12, 12])
ax.set_ylim([-6, 6])
ax.set_zlim([-4, 6])

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/P1_07_three_stage_collapse.png',
            dpi=300, facecolor=DARK_BG, bbox_inches='tight')
print("✓ Three-Stage Collapse visualization created")
plt.close()
