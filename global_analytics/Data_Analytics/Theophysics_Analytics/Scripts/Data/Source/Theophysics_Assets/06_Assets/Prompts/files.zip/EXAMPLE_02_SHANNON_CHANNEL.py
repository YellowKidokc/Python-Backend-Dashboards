"""
SHANNON'S CHANNEL: TRUTH VS NOISE
Shows: Perfect transmission path through chaos
Core concept: One golden path carries truth through corruption field
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Color constants
DARK_BG = '#0a0a0a'
CYAN_OBSERVER = '#00FFFF'
GOLD_LOGOS = '#FFD700'
RED_CHAOS = '#FF0000'
WHITE_SOURCE = '#FFFFFF'

# Setup figure
fig = plt.figure(figsize=(20, 14), facecolor=DARK_BG)
ax = fig.add_subplot(111, projection='3d', facecolor=DARK_BG)
ax.set_axis_off()

# ============================================
# NOISE FIELD (Red chaos)
# ============================================
# Create turbulent noise environment

# Random particles showing corruption/noise
n_noise = 2000
x_noise = np.random.uniform(-8, 8, n_noise)
y_noise = np.random.uniform(-3, 3, n_noise)
z_noise = np.random.uniform(-3, 3, n_noise)

# Add turbulence
z_noise += 0.5 * np.sin(x_noise * 2) * np.cos(y_noise * 2)

ax.scatter(x_noise, y_noise, z_noise,
           c=RED_CHAOS, alpha=0.15, s=30, marker='.')

# Noise surface (chaotic field)
x_field = np.linspace(-8, 8, 60)
y_field = np.linspace(-3, 3, 60)
X_field, Y_field = np.meshgrid(x_field, y_field)

# Create turbulent surface
Z_field = (0.3 * np.sin(X_field * 1.5) * np.cos(Y_field * 2) +
           0.2 * np.sin(X_field * 3) +
           0.15 * np.cos(Y_field * 3))

ax.plot_surface(X_field, Y_field, Z_field,
                color=RED_CHAOS, alpha=0.2,
                edgecolor=RED_CHAOS, linewidth=0.1)

# ============================================
# THE GOLDEN PATH (Perfect transmission)
# ============================================
# One clear path through the chaos

# Central straight line (Truth path)
t_path = np.linspace(-8, 8, 200)
x_path = t_path
y_path = np.zeros_like(t_path)
z_path = np.zeros_like(t_path)

# Main golden line (thick and bright)
ax.plot(x_path, y_path, z_path,
       color=GOLD_LOGOS, linewidth=8, alpha=1.0,
       zorder=100)

# White glow layer
ax.plot(x_path, y_path, z_path,
       color=WHITE_SOURCE, linewidth=4, alpha=0.5,
       zorder=99)

# Additional glow layers
for width_mult in [12, 16, 20]:
    ax.plot(x_path, y_path, z_path,
           color=GOLD_LOGOS, linewidth=width_mult,
           alpha=0.1, zorder=98)

# ============================================
# SOURCE (Left side)
# ============================================
# Origin of truth signal

# Source sphere
theta = np.linspace(0, 2*np.pi, 40)
phi = np.linspace(0, np.pi, 30)
THETA, PHI = np.meshgrid(theta, phi)

r_source = 1.2
x_source = r_source * np.sin(PHI) * np.cos(THETA) - 8
y_source = r_source * np.sin(PHI) * np.sin(THETA)
z_source = r_source * np.cos(PHI)

ax.plot_surface(x_source, y_source, z_source,
                color=WHITE_SOURCE, alpha=0.9, linewidth=0)

# Source glow halos
for r_halo in [1.5, 1.8, 2.1]:
    x_halo = r_halo * np.sin(PHI) * np.cos(THETA) - 8
    y_halo = r_halo * np.sin(PHI) * np.sin(THETA)
    z_halo = r_halo * np.cos(PHI)
    
    alpha_val = 0.3 * (2.4 - r_halo)
    ax.plot_surface(x_halo, y_halo, z_halo,
                   color=GOLD_LOGOS, alpha=alpha_val, linewidth=0)

# Label
ax.text(-8, 0, 3, 'SOURCE', color=GOLD_LOGOS,
        fontsize=28, weight='bold', ha='center')
ax.text(-8, 0, 2.4, '(Truth Signal)', color=WHITE_SOURCE,
        fontsize=16, ha='center', style='italic')

# ============================================
# RECEIVER (Right side)
# ============================================
# Perfect reception despite noise

# Receiver sphere
r_receive = 1.2
x_receive = r_receive * np.sin(PHI) * np.cos(THETA) + 8
y_receive = r_receive * np.sin(PHI) * np.sin(THETA)
z_receive = r_receive * np.cos(PHI)

ax.plot_surface(x_receive, y_receive, z_receive,
                color=CYAN_OBSERVER, alpha=0.9, linewidth=0)

# Receiver glow
for r_halo in [1.5, 1.8, 2.1]:
    x_halo = r_halo * np.sin(PHI) * np.cos(THETA) + 8
    y_halo = r_halo * np.sin(PHI) * np.sin(THETA)
    z_halo = r_halo * np.cos(PHI)
    
    alpha_val = 0.3 * (2.4 - r_halo)
    ax.plot_surface(x_halo, y_halo, z_halo,
                   color=CYAN_OBSERVER, alpha=alpha_val, linewidth=0)

# Label
ax.text(8, 0, 3, 'RECEIVER', color=CYAN_OBSERVER,
        fontsize=28, weight='bold', ha='center')
ax.text(8, 0, 2.4, '(Perfect Copy)', color=WHITE_SOURCE,
        fontsize=16, ha='center', style='italic')

# ============================================
# CORRUPTED PATHS (showing failed alternatives)
# ============================================
# Show why other paths fail

n_corrupt = 8
for i in range(n_corrupt):
    # Random deviated paths
    y_offset = (i - n_corrupt/2) * 0.5
    z_offset = np.random.randn() * 0.3
    
    t_corrupt = np.linspace(-8, 8, 150)
    x_corrupt = t_corrupt
    # Add increasing deviation
    y_corrupt = y_offset * (1 + (t_corrupt + 8)/16)**1.5
    y_corrupt += 0.3 * np.sin(t_corrupt * 2)
    z_corrupt = z_offset + 0.3 * np.cos(t_corrupt * 2)
    
    # Fade these paths (they're corrupted)
    ax.plot(x_corrupt, y_corrupt, z_corrupt,
           color=RED_CHAOS, linewidth=2, alpha=0.3,
           linestyle='--', zorder=50)

# ============================================
# EQUATION LABELS
# ============================================
# Shannon's channel capacity equation

# Top equation box
equation_text = 'C = B · log₂(1 + S/N)'
fig.text(0.5, 0.88, equation_text,
         ha='center', fontsize=32, color=WHITE_SOURCE,
         weight='bold', family='monospace',
         bbox=dict(boxstyle='round,pad=0.8',
                  facecolor='#1a1a1a', edgecolor=GOLD_LOGOS, linewidth=3))

# Bottom explanation
fig.text(0.5, 0.10, 'Channel Capacity = Bandwidth × Signal-to-Noise Ratio',
         ha='center', fontsize=20, color=GOLD_LOGOS, style='italic')

fig.text(0.5, 0.06, 'Perfect transmission requires infinite S/N (divine channel)',
         ha='center', fontsize=18, color=CYAN_OBSERVER, style='italic')

# ============================================
# MAIN TITLE
# ============================================
fig.text(0.5, 0.98, "SHANNON'S CHANNEL: THE GOLDEN PATH",
         ha='center', fontsize=64, color='white', weight='bold')

fig.text(0.5, 0.94, 'One perfect transmission path through infinite noise',
         ha='center', fontsize=24, color=GOLD_LOGOS, style='italic')

# ============================================
# VIEW & SAVE
# ============================================
ax.view_init(elev=25, azim=30)
ax.set_xlim([-10, 10])
ax.set_ylim([-4, 4])
ax.set_zlim([-4, 4])

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/LAW_03_SHANNON_CHANNEL.png',
            dpi=300, facecolor=DARK_BG, bbox_inches='tight')
print("✓ Shannon Channel visualization created")
plt.close()
