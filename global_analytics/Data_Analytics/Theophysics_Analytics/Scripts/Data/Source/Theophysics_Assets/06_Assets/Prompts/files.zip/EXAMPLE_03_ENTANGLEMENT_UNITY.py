"""
QUANTUM ENTANGLEMENT: NON-LOCAL UNITY
Shows: Instantaneous correlation across distance
Core concept: Two particles sharing single quantum state
"""

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# Color constants
DARK_BG = '#0a0a0a'
CYAN_OBSERVER = '#00FFFF'
GOLD_LOGOS = '#FFD700'
PURPLE_FIELD = '#9933FF'
WHITE_SOURCE = '#FFFFFF'

# Setup figure
fig = plt.figure(figsize=(20, 14), facecolor=DARK_BG)
ax = fig.add_subplot(111, projection='3d', facecolor=DARK_BG)
ax.set_axis_off()

# ============================================
# CENTRAL SOURCE (entanglement creation)
# ============================================
# Two particles created in single quantum state

# Central interaction sphere
theta = np.linspace(0, 2*np.pi, 50)
phi = np.linspace(0, np.pi, 40)
THETA, PHI = np.meshgrid(theta, phi)

r_center = 0.8
x_center = r_center * np.sin(PHI) * np.cos(THETA)
y_center = r_center * np.sin(PHI) * np.sin(THETA)
z_center = r_center * np.cos(PHI)

ax.plot_surface(x_center, y_center, z_center,
                color=WHITE_SOURCE, alpha=0.9, linewidth=0)

# Glow halos
for r_halo in [1.2, 1.6, 2.0]:
    x_halo = r_halo * np.sin(PHI) * np.cos(THETA)
    y_halo = r_halo * np.sin(PHI) * np.sin(THETA)
    z_halo = r_halo * np.cos(PHI)
    
    alpha_val = 0.4 * (2.4 - r_halo)
    ax.plot_surface(x_halo, y_halo, z_halo,
                   color=PURPLE_FIELD, alpha=alpha_val, linewidth=0)

# ============================================
# LEFT PARTICLE
# ============================================
# First entangled particle (moves left)

x_left = -7
y_left = 0
z_left = 0

# Particle sphere
r_particle = 1.0
x_part_left = r_particle * np.sin(PHI) * np.cos(THETA) + x_left
y_part_left = r_particle * np.sin(PHI) * np.sin(THETA) + y_left
z_part_left = r_particle * np.cos(PHI) + z_left

ax.plot_surface(x_part_left, y_part_left, z_part_left,
                color=CYAN_OBSERVER, alpha=0.8, linewidth=0)

# Glow
for r_glow in [1.3, 1.6]:
    x_glow = r_glow * np.sin(PHI) * np.cos(THETA) + x_left
    y_glow = r_glow * np.sin(PHI) * np.sin(THETA) + y_left
    z_glow = r_glow * np.cos(PHI) + z_left
    
    alpha_val = 0.3 * (1.9 - r_glow)
    ax.plot_surface(x_glow, y_glow, z_glow,
                   color=CYAN_OBSERVER, alpha=alpha_val, linewidth=0)

# Label
ax.text(x_left, y_left, z_left+2.5, 'PARTICLE A',
        color=CYAN_OBSERVER, fontsize=24, weight='bold', ha='center')

# ============================================
# RIGHT PARTICLE
# ============================================
# Second entangled particle (moves right)

x_right = 7
y_right = 0
z_right = 0

# Particle sphere
x_part_right = r_particle * np.sin(PHI) * np.cos(THETA) + x_right
y_part_right = r_particle * np.sin(PHI) * np.sin(THETA) + y_right
z_part_right = r_particle * np.cos(PHI) + z_right

ax.plot_surface(x_part_right, y_part_right, z_part_right,
                color=GOLD_LOGOS, alpha=0.8, linewidth=0)

# Glow
for r_glow in [1.3, 1.6]:
    x_glow = r_glow * np.sin(PHI) * np.cos(THETA) + x_right
    y_glow = r_glow * np.sin(PHI) * np.sin(THETA) + y_right
    z_glow = r_glow * np.cos(PHI) + z_right
    
    alpha_val = 0.3 * (1.9 - r_glow)
    ax.plot_surface(x_glow, y_glow, z_glow,
                   color=GOLD_LOGOS, alpha=alpha_val, linewidth=0)

# Label
ax.text(x_right, y_right, z_right+2.5, 'PARTICLE B',
        color=GOLD_LOGOS, fontsize=24, weight='bold', ha='center')

# ============================================
# CONNECTING FIELD
# ============================================
# Non-local correlation (not causal connection!)

# Create field lines showing correlation
n_field_lines = 16
for i in range(n_field_lines):
    angle = i * 2*np.pi / n_field_lines
    y_offset = 2.5 * np.sin(angle)
    z_offset = 2.5 * np.cos(angle)
    
    # Field line from left to right
    t_line = np.linspace(-7, 7, 100)
    x_line = t_line
    y_line = y_offset * np.exp(-((t_line)**2)/25)
    z_line = z_offset * np.exp(-((t_line)**2)/25)
    
    # Pulsing effect
    alpha_pulse = 0.3 + 0.2 * np.sin(angle * 3)
    
    ax.plot(x_line, y_line, z_line,
           color=PURPLE_FIELD, linewidth=2, alpha=alpha_pulse,
           linestyle='-')

# Central field tube (stronger connection)
n_tube_rings = 30
for i in range(n_tube_rings):
    x_pos = -6 + i * (12/n_tube_rings)
    ring_radius = 1.5 * np.exp(-(x_pos**2)/20)
    
    for j in range(20):
        angle = j * 2*np.pi / 20
        y_pos = ring_radius * np.sin(angle)
        z_pos = ring_radius * np.cos(angle)
        
        ax.scatter([x_pos], [y_pos], [z_pos],
                  c=PURPLE_FIELD, s=50, alpha=0.15, marker='o')

# ============================================
# SEPARATION ARROWS
# ============================================
# Show particles moving apart but remaining connected

# Left arrow (particle moving away from center)
ax.plot([-1, -5], [0, 0], [3, 3],
       color=WHITE_SOURCE, linewidth=4, alpha=0.6)
ax.scatter([-5], [0], [3], c=WHITE_SOURCE, s=300, marker='<')

# Right arrow (particle moving away from center)
ax.plot([1, 5], [0, 0], [3, 3],
       color=WHITE_SOURCE, linewidth=4, alpha=0.6)
ax.scatter([5], [0], [3], c=WHITE_SOURCE, s=300, marker='>')

# Distance label
ax.text(0, 0, 4, 'SPATIAL SEPARATION', color=WHITE_SOURCE,
        fontsize=20, ha='center', weight='bold')
ax.text(0, 0, 3.5, '(No loss of correlation)', color=PURPLE_FIELD,
        fontsize=16, ha='center', style='italic')

# ============================================
# MAIN TITLE
# ============================================
fig.text(0.5, 0.98, 'QUANTUM ENTANGLEMENT: NON-LOCAL UNITY',
         ha='center', fontsize=64, color='white', weight='bold')

fig.text(0.5, 0.94, 'Instantaneous correlation transcends spacetime separation',
         ha='center', fontsize=24, color=PURPLE_FIELD, style='italic')

# ============================================
# EQUATION & EXPLANATION
# ============================================
# Bell's theorem violation equation
equation_text = '|Ψ⟩ = (|↑⟩A|↓⟩B - |↓⟩A|↑⟩B) / √2'
fig.text(0.5, 0.88, equation_text,
         ha='center', fontsize=28, color=WHITE_SOURCE,
         weight='bold', family='monospace',
         bbox=dict(boxstyle='round,pad=0.6',
                  facecolor='#1a1a1a', edgecolor=PURPLE_FIELD, linewidth=2))

# Bottom tagline
fig.text(0.5, 0.08, 'Measure A → Instantly determines B (regardless of distance)',
         ha='center', fontsize=22, color=CYAN_OBSERVER, style='italic')

fig.text(0.5, 0.04, 'Not "spooky action" but shared quantum state',
         ha='center', fontsize=20, color=PURPLE_FIELD, style='italic')

# ============================================
# VIEW & SAVE
# ============================================
ax.view_init(elev=20, azim=30)
ax.set_xlim([-10, 10])
ax.set_ylim([-5, 5])
ax.set_zlim([-4, 5])

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/LAW_09_ENTANGLEMENT_UNITY.png',
            dpi=300, facecolor=DARK_BG, bbox_inches='tight')
print("✓ Entanglement Unity visualization created")
plt.close()
